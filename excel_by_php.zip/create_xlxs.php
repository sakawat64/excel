<?php
session_start();

$user_id = isset($_SESSION['UserId']) ? $_SESSION['UserId']:NULL;
$FullName = isset($_SESSION['FullName']) ? $_SESSION['FullName']:NULL;
$UserName = isset($_SESSION['UserName'])? $_SESSION['UserName']:NULL;
$PhotoPath = isset($_SESSION['PhotoPath'])? $_SESSION['PhotoPath']:NULL;
$ty = isset($_SESSION['UserType'])? $_SESSION['UserType']:NULL;

if (!empty($_SESSION['UserId'])) {

//========================================
    include '../model/oop.php';
    $obj = new Controller();
    include '../model/Bill.php';
    $bill = new Bill();
//======= Object Created from Class ======

    function view_all_agent_for_excel($table_name, $where_cond)
    {
        global $obj;

        $data = array();
        $sql = "SELECT 'Fair Broadband Service' AS Name_of_Operator,
                        'Home' AS Type_of_Clients, 
                        'Malibagh' AS Distribution_Location_Point,
                        agent.ag_name AS Name_of_Clients,
                        'Wired' AS Type_of_Connection,
                        'Shared' AS Type_of_Connectivity,
                        agent.connection_date AS Activation_Date, 
                        agent.mb AS Bandwidth_Allocation_MB, 
                        agent.ip AS Allowcated_Ip,
                        '' AS House_No,
                        '' AS Road_No,
                         agent.ag_office_address AS Area,
                        'Dhaka' AS District,
                        'Malibagh' AS Thana,
                        agent.ag_mobile_no AS Client_Phone,
                        agent.ag_email AS Mail,
                        agent.taka AS Selling_BandwidthBDT_Excluding_VAT
                        
                        FROM tbl_agent AS agent  
                        LEFT JOIN `tbl_zone` ON ( `agent`.`zone` = `tbl_zone`.`zone_id` ) WHERE ag_status = 1 ";
        $q = $obj->con->prepare($sql);
        $q->execute();

        while ($row = $q->fetch(PDO::FETCH_ASSOC)) {
            $data[] = $row;
        }
        return $data;
    }

    $allAgentData = view_all_agent_for_excel('tbl_agent', 'ag_status = 1');
    /*
     * All value from database is sotred in $allAgentData, now call PHPExcell class
     */

    include 'PHPExcel.php';
    $phpExcel = new PHPExcel();
    /*
     *  At first we declare basic properties of excel document
     */
    $phpExcel -> getProperties()
                    ->setCreated('BSD-ISP-Robot')
                    ->setLastModifiedBy('BSD-ISP')
                    ->setTitle('CATEGORY ISP Client Information')
                    ->setKeywords('ISP Clients by BSD-ISP Robot');
    /*
     * Then the all cell will be vertical top and horizontal center
     */
    $phpExcel -> getDefaultStyle()
                    ->getAlignment()
                    ->setVertical(
                        PHPExcel_Style_Alignment::VERTICAL_TOP);
    $phpExcel -> getDefaultStyle()
                    ->getAlignment()
                    ->setHorizontal(
                        PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    /*
     *  The Font and Font size will be set down here
     */
    $phpExcel -> getDefaultStyle()
                    ->getFont()
                    ->setName('Arial');
    $phpExcel -> getDefaultStyle()
                    ->getFont()
                    -> setSize(8);
    /*
     *  Declare the Active Sheet, 1st sheet = 0
     */
    $phpExcel -> setActiveSheetIndex(0);
    /*
     * Now Every time we need this active sheet. so lets wrap in a variable for easy use
     */
    $activeSheet = $phpExcel -> getActiveSheet();
    /*
     * Lets make page setup to Landscape mode and width is fit when print
     */
    $activeSheet -> getPageSetup()
                    ->setOrientation(
                        PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
    /*
     *  Set the header and footer
     */
    $activeSheet -> getHeaderFooter()// The title will be header of this file
                    ->setOddHeader('&C&B12'.$phpExcel->getProperties()->getTitle())
                    ->setOddFooter('&LISP Information &CPage &P of &N &R&D');
    /*
     * End of Page design now Starting write cell content
     */

    // Cell additional Style
    $cellStyleBold = array(
        'font' => array(
            'bold' => true
        )
    );
    $cellStyle9Size = array(
        'font' => array(
            'size' => 9,
        )
    );

    $cellAlignleft = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
        )
    );
    $cellBorder = array(
        'borders' => array(
            'allborders' => array(
                'style' => PHPExcel_Style_Border::BORDER_THIN
            )
        )
    );

    /*
     * Make some cell marge and bold
     */
    for ($i = 1; $i <= 4; $i++){
        $activeSheet -> mergeCells("A$i:B$i");
        $activeSheet -> mergeCells("C$i:E$i");
        $activeSheet -> getStyle("A$i:F$i")->applyFromArray($cellStyleBold);
        $activeSheet -> getStyle("A".$i.":F".$i."")->applyFromArray($cellBorder);
    }
    $activeSheet -> getStyle('A1:K14')->applyFromArray($cellStyle9Size);
    $activeSheet -> mergeCells("J2:K2");
    $activeSheet -> mergeCells("J3:K3");
    /*
     * Setting up the Column size for full page print
     */
    for($n = 'A'; $n <= 'L'; $n++){

        if($n == 'A'){
            $activeSheet -> getColumnDimension($n) -> setWidth(5);
        }
        else if ($n == 'B'){
            $activeSheet -> getColumnDimension($n) -> setWidth(26);
        }
        else if ($n == 'E'){
            $activeSheet -> getColumnDimension($n) -> setWidth(25);
        }
        else if ($n == 'P'){
            $activeSheet -> getColumnDimension($n) -> setWidth(25);
        }
        else if ($n == 'G'){
            $activeSheet -> getColumnDimension($n) -> setWidth(25);
        }
        else if ($n == 'H'){
            $activeSheet -> getColumnDimension($n) -> setWidth(25);
        }
        else if ($n == 'I'){
            $activeSheet -> getColumnDimension($n) -> setWidth(25);
        }
        else if ($n == 'J'){
            $activeSheet -> getColumnDimension($n) -> setWidth(15);
        }
        else if ($n == 'L'){
            $activeSheet -> getColumnDimension($n) -> setWidth(5);
        }
        else{
            $activeSheet -> getColumnDimension($n) -> setWidth(11);
        }

    }
    /*
     * Setting up the heading of the file
     */
    $activeSheet -> setCellValue('A1','Category ISP Name : ');
    $activeSheet -> setCellValue('A2','Type of Category :');
    $activeSheet -> setCellValue('A3','Permitted Area/Thana:');

    $activeSheet -> setCellValue('C1','Fair Broadband Service');
    $activeSheet -> setCellValue('C2','CAT-A');
    $activeSheet -> setCellValue('C3','Dhaka');

    $activeSheet -> setCellValue('J2','Reporting Month');
    $activeSheet -> setCellValue('L2',date("F"));

    $activeSheet -> setCellValue('J3','Year');
    $activeSheet -> setCellValue('L3',date("Y"));

    $activeSheet -> getStyle("C1:C8")->applyFromArray($cellAlignleft);
    $activeSheet -> getStyle("B6:H6")->applyFromArray($cellStyleBold);

    $activeSheet -> getStyle("J2:K3")->applyFromArray($cellBorder);
    $activeSheet -> getStyle("L2:L3")->applyFromArray($cellBorder);

    /*
     * Setting up Header row of the table data in $tableHeader variable
     */
    $col = 'B';
    $rowNum = 7;
    $oneHeaderRowFlag = true;
    $serial = 1;

    foreach ($allAgentData as $agentData) {
        if ($oneHeaderRowFlag == true) {
                $tableHeader = array_keys($agentData);
                $oneHeaderRowFlag = false;
        }
    }

    /*
     * Insert "SL" Cell to table
     */
    $activeSheet -> setCellValue('A7','SL');
    $activeSheet -> getStyle('A7')->applyFromArray($cellStyleBold);
    $activeSheet -> getStyle('A7')->applyFromArray($cellBorder);
    /*
     * Insert full Table Header by foreach loop form $tableHeader variable
     */
    foreach ($tableHeader as $cellHeader){
        $activeSheet -> setCellValue($col.$rowNum, str_replace('_',' ',$cellHeader));
        $activeSheet -> getStyle($col.$rowNum)->applyFromArray($cellStyleBold);
        $activeSheet -> getStyle($col.$rowNum)->applyFromArray($cellBorder);
        $activeSheet -> getStyle($col.$rowNum)->getAlignment()->setWrapText(true);
        $col++;
    }
    /*
     * Set Table Heading little bigger in height
     */
    $activeSheet->getRowDimension($rowNum)->setRowHeight(60);
    /*
     * Add table content in cell from database
     */
    foreach ($allAgentData as $agentDataForTable) {
        $col = 'B';// Make Column start form A and row number will increase in foreach loop
        $rowNum++;
        /*
         * Write Serial number...
         */
        $activeSheet->setCellValue('A'. $rowNum, $serial);
        $activeSheet->getStyle('A'. $rowNum)->applyFromArray($cellBorder);

        /*
         *  get table content in string form array by using nested foreach loop.
         */
        foreach ($agentDataForTable as $singleDataForCell) {

            if($col == 'H'){

                $activeSheet->setCellValue($col . $rowNum, date_format(date_create($singleDataForCell),"m/d/Y"));
            }else{
                $activeSheet->setCellValue($col . $rowNum, $singleDataForCell);
            }

            $activeSheet->getStyle($col . $rowNum)->applyFromArray($cellBorder);
            $activeSheet->getStyle($col . $rowNum)->getAlignment()->setWrapText(true);

            $col++;
        }
        $serial++;
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="ISP_Excel_Sheet.xlsx"');
    header('Cache-Control: max-age=0');
    $objWriter = PHPExcel_IOFactory::createWriter($phpExcel, 'Excel2007');
    $objWriter->save('php://output');

}
else{ header("location: ../include/login.php");}
?>